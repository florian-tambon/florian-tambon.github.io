---
title: "CV"
permalink: /files/cv.pdf
author_profile: true
redirect_from:
  - /resume
---
