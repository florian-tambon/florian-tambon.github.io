---
title: "CV"
permalink: /files/dummy_cv.pdf
author_profile: true
redirect_from:
  - /resume
---
